# Smart Person Identification & Presence Tracker

Competition-ready clean rebuild of **Identification Of Person Without Location Tracking**.

## Core idea

Verify who is physically present at a controlled point without continuously tracking the person's GPS/location.

### System flow

Browser camera
→ YuNet face detection
→ SFace feature extraction
→ identity matching
→ basic motion/liveness gate
→ presence / unknown event
→ dashboard + audit history

## Main screens

- `/` — live monitoring
- `/admin-panel/` — administrator dashboard
- `/register/` — registration API
- `/recognize/` — recognition API
- `/events/` — recent event API

## Features in this clean rebuild

- Multi-face detection in one frame
- SFace recognition
- Registered-person management
- Presence logging with 10-minute duplicate suppression
- Unknown-person event logging
- Full-screen browser alert for unknown faces
- Audible alert using browser Web Audio API
- Event timeline and statistics
- Basic motion-based liveness gate
- No GPS or location collection
- Face templates stored instead of raw registration images
- CSRF-protected POST requests
- Windows setup scripts

### Important security note

The included liveness check is a **basic motion/temporal heuristic**, useful for demonstrating the anti-spoofing concept. It is not a certified anti-spoofing system and should not be presented as defeating every replay attack. A strong production system would use a dedicated presentation-attack-detection model and/or hardware depth/IR sensing.

## Run on Windows 11

Recommended: Python 3.12 or 3.13.

1. Install Python.
2. Open PowerShell in this folder.
3. Run:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python download_models.py
python manage.py migrate
python manage.py runserver 127.0.0.1:8000
```

4. Open `http://127.0.0.1:8000/`
5. Allow camera access.

If PowerShell blocks activation, use:

```powershell
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe download_models.py
.venv\Scripts\python.exe manage.py migrate
.venv\Scripts\python.exe manage.py runserver 127.0.0.1:8000
```

## Competition demo

1. Open Admin Panel.
2. Register 2–3 people using clear front-facing photos.
3. Open Live Monitor.
4. Show a registered person → green identity.
5. Show an unregistered person → red full-screen alert + beep.
6. Move the registered person → repeated frames remain recognized while duplicate presence records are suppressed.
7. Demonstrate the liveness indicator and explain that it is a basic temporal gate.
8. Open the event history to show the audit trail.

## Model sources

YuNet and SFace are OpenCV Zoo models. The project downloads them automatically rather than committing large ONNX files to Git.
