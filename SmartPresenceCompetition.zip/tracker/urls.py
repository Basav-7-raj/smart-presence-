from django.urls import path
from . import views

urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("admin-panel/", views.admin_panel, name="admin_panel"),
    path("register/", views.register_face, name="register_face"),
    path("recognize/", views.recognize, name="recognize"),
    path("events/", views.events, name="events"),
]
