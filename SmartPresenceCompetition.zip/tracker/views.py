import time
from datetime import timedelta

import cv2
import numpy as np
from django.http import JsonResponse
from django.shortcuts import render
from django.utils import timezone
from django.views.decorators.http import require_GET, require_POST

from .face_engine import detect_faces, extract_best_feature, compare_features, feature_from_json
from .models import PersonProfile, PresenceRecord, UnknownEvent

MATCH_THRESHOLD = 0.363
LIVENESS_WINDOW_SECONDS = 4.0
LIVENESS_MIN_MOVEMENT = 0.018

# Demo-only in-memory temporal state. It is deliberately not persistent.
_liveness_state = {}

def _client_key(request):
    return request.headers.get("X-Client-ID", "default-client")

def _liveness_check(client_id, face):
    now = time.monotonic()
    x, y, w, h = face["bbox"]
    cx = (x + w / 2) / max(1, w)
    cy = (y + h / 2) / max(1, h)
    # normalized position within the current face box is stable; use landmark geometry instead
    pts = np.asarray(face["landmarks"], dtype=np.float32)
    scale = max(np.linalg.norm(pts[0] - pts[1]), 1.0)
    nose = pts[2]
    left_eye, right_eye = pts[0], pts[1]
    geom = np.array([
        (nose[0] - left_eye[0]) / scale,
        (nose[1] - (left_eye[1] + right_eye[1]) / 2) / scale,
        (right_eye[0] - left_eye[0]) / scale,
    ], dtype=np.float32)

    state = _liveness_state.get(client_id)
    current = {"t": now, "cx": cx, "cy": cy, "geom": geom}

    if state is None or now - state["t"] > LIVENESS_WINDOW_SECONDS:
        _liveness_state[client_id] = current
        return False, "Move your head slightly for liveness verification."

    delta = float(np.linalg.norm(geom - state["geom"]))
    _liveness_state[client_id] = current

    # This is a basic temporal heuristic, not a certified PAD system.
    if delta >= LIVENESS_MIN_MOVEMENT:
        return True, "Liveness verified"

    return False, "Move your head slightly for liveness verification."

def dashboard(request):
    people = PersonProfile.objects.order_by("name")
    records = PresenceRecord.objects.select_related("person")[:20]
    unknowns = UnknownEvent.objects[:20]
    return render(request, "tracker/dashboard.html", {
        "people": people,
        "records": records,
        "unknowns": unknowns,
        "people_count": people.count(),
        "presence_count": PresenceRecord.objects.filter(
            timestamp__date=timezone.localdate()
        ).count(),
        "unknown_count": UnknownEvent.objects.filter(
            timestamp__date=timezone.localdate()
        ).count(),
    })

def admin_panel(request):
    people = PersonProfile.objects.order_by("name")
    records = PresenceRecord.objects.select_related("person")[:50]
    unknowns = UnknownEvent.objects[:50]
    return render(request, "tracker/admin_panel.html", {
        "people": people,
        "records": records,
        "unknowns": unknowns,
        "people_count": people.count(),
        "presence_count": PresenceRecord.objects.filter(
            timestamp__date=timezone.localdate()
        ).count(),
        "unknown_count": UnknownEvent.objects.filter(
            timestamp__date=timezone.localdate()
        ).count(),
    })

@require_POST
def register_face(request):
    name = request.POST.get("name", "").strip()
    student_id = request.POST.get("student_id", "").strip()
    image = request.FILES.get("image")

    if not name or not student_id or not image:
        return JsonResponse({"status": "error", "message": "Name, Student ID and photo are required."}, status=400)

    try:
        data = np.frombuffer(image.read(), np.uint8)
        frame = cv2.imdecode(data, cv2.IMREAD_COLOR)
        if frame is None:
            raise ValueError("Invalid image file.")

        feature, face = extract_best_feature(frame)
        if feature is None:
            return JsonResponse({"status": "error", "message": "No clear face found. Use a front-facing photo."}, status=400)

        person, _ = PersonProfile.objects.get_or_create(student_id=student_id)
        person.name = name
        person.set_encoding(feature)
        person.save()

        return JsonResponse({"status": "success", "message": f"{name} registered successfully."})
    except Exception as exc:
        return JsonResponse({"status": "error", "message": str(exc)}, status=500)

@require_POST
def recognize(request):
    try:
        data = np.frombuffer(request.body, np.uint8)
        frame = cv2.imdecode(data, cv2.IMREAD_COLOR)
        if frame is None:
            return JsonResponse({"status": "error", "message": "Invalid frame."}, status=400)

        faces = detect_faces(frame)
        if not faces:
            return JsonResponse({"status": "success", "recognized": False, "face_count": 0, "message": "No face detected."})

        people = list(PersonProfile.objects.all())
        client_id = _client_key(request)
        results = []

        for face in faces:
            raw = np.zeros((15,), dtype=np.float32)
            raw[:4] = face["bbox"]
            raw[4:14] = np.asarray(face["landmarks"]).reshape(-1)
            raw[14] = face["score"]

            from .face_engine import extract_feature_from_face
            feature = extract_feature_from_face(frame, raw)

            best_person = None
            best_score = -1.0
            for person in people:
                try:
                    score = compare_features(feature, feature_from_json(person.encoding_json))
                    if score > best_score:
                        best_score = score
                        best_person = person
                except Exception:
                    continue

            live_ok, live_message = _liveness_check(client_id, face)

            if best_person is not None and best_score >= MATCH_THRESHOLD and live_ok:
                since = timezone.now() - timedelta(minutes=10)
                already = PresenceRecord.objects.filter(
                    person=best_person, timestamp__gte=since
                ).exists()
                if not already:
                    PresenceRecord.objects.create(
                        person=best_person, device_source="Browser Webcam"
                    )

                results.append({
                    "recognized": True,
                    "name": best_person.name,
                    "student_id": best_person.student_id,
                    "score": round(best_score, 3),
                    "liveness": True,
                    "bbox": face["bbox"],
                })
            else:
                # Only log unknown events when the face is reasonably confident as a face.
                UnknownEvent.objects.create(
                    best_score=max(0.0, best_score),
                    liveness_passed=live_ok,
                    source="Browser Webcam",
                )
                results.append({
                    "recognized": False,
                    "message": (
                        "Liveness verification required."
                        if best_person is not None and best_score >= MATCH_THRESHOLD
                        else "Unknown person."
                    ),
                    "score": round(max(0.0, best_score), 3),
                    "liveness": live_ok,
                    "bbox": face["bbox"],
                })

        recognized_count = sum(1 for r in results if r["recognized"])
        return JsonResponse({
            "status": "success",
            "recognized": recognized_count > 0,
            "face_count": len(results),
            "results": results,
        })
    except Exception as exc:
        return JsonResponse({"status": "error", "message": str(exc)}, status=500)

@require_GET
def events(request):
    return JsonResponse({
        "presence": list(PresenceRecord.objects.select_related("person").values(
            "person__name", "person__student_id", "timestamp", "device_source"
        )[:50]),
        "unknown": list(UnknownEvent.objects.values(
            "timestamp", "best_score", "liveness_passed", "source"
        )[:50]),
    })
