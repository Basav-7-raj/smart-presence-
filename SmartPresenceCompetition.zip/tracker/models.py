import json
from django.db import models

class PersonProfile(models.Model):
    name = models.CharField(max_length=100)
    student_id = models.CharField(max_length=50, unique=True)
    encoding_json = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def set_encoding(self, feature):
        self.encoding_json = json.dumps(feature)

    def get_encoding(self):
        return json.loads(self.encoding_json)

    def __str__(self):
        return f"{self.name} ({self.student_id})"


class PresenceRecord(models.Model):
    person = models.ForeignKey(PersonProfile, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
    device_source = models.CharField(max_length=120, default="Browser Webcam")

    class Meta:
        ordering = ["-timestamp"]

    def __str__(self):
        return f"{self.person.name} - {self.timestamp}"


class UnknownEvent(models.Model):
    timestamp = models.DateTimeField(auto_now_add=True)
    best_score = models.FloatField(default=0.0)
    liveness_passed = models.BooleanField(default=False)
    source = models.CharField(max_length=120, default="Browser Webcam")

    class Meta:
        ordering = ["-timestamp"]

    def __str__(self):
        return f"Unknown - {self.timestamp}"
