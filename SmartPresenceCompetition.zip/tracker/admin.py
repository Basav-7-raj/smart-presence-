from django.contrib import admin
from .models import PersonProfile, PresenceRecord, UnknownEvent

@admin.register(PersonProfile)
class PersonProfileAdmin(admin.ModelAdmin):
    list_display = ("name", "student_id", "created_at")
    search_fields = ("name", "student_id")

@admin.register(PresenceRecord)
class PresenceRecordAdmin(admin.ModelAdmin):
    list_display = ("person", "timestamp", "device_source")
    list_filter = ("timestamp",)

@admin.register(UnknownEvent)
class UnknownEventAdmin(admin.ModelAdmin):
    list_display = ("timestamp", "best_score", "liveness_passed", "source")
    list_filter = ("liveness_passed",)
