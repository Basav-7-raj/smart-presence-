@echo off
title Smart Presence Setup
echo.
echo ============================================
echo   SMART PRESENCE - WINDOWS SETUP
echo ============================================
echo.
py -3.12 -m venv .venv
if errorlevel 1 (
  echo Could not create Python 3.12 environment.
  echo Install Python 3.12 and try again.
  pause
  exit /b 1
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
python download_models.py
python manage.py migrate
echo.
echo Setup complete.
echo Start the application with:
echo   .venv\Scripts\python.exe manage.py runserver 127.0.0.1:8000
pause
